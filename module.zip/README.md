![Latest version](https://img.shields.io/github/v/tag/kid2407/baka-chat?label=Latest%20Version&sort=semver)
![Latest Release Download Count](https://img.shields.io/github/downloads/kid2407/baka-chat/latest/module.zip?label=Downloads(latest))
![Forge Installs](https://img.shields.io/badge/dynamic/json?label=Forge%20Installs&query=package.installs&suffix=%25&url=https%3A%2F%2Fforge-vtt.com%2Fapi%2Fbazaar%2Fpackage%2Fbaka-chat&colorB=4aa94a)

# Baka Chat
A small Foundry module to make natural 1s and 20s more fun.

Ever wanted to be praised on that Nat 20 or feel ashamed when you rolled a Nat 1? Well, then this is a module for you, for you will be judged on every Nat 20 or Nat 1 you roll - enjoy!

You can use your own images instead of the provided ones - just choose one in the settings.

## Supported Modules:
* [Better Rolls 5E](https://foundryvtt.com/packages/betterrolls5e)

### Ko-Fi

If you have read this far and want to show some more appreciation: I have a Ko-Fi, should you consider what I'm doing worth a little something. Of course I do not expect nor require anyone to use it, but I'll leave it here in case someone wants to give:

[![ko-fi](https://ko-fi.com/img/githubbutton_sm.svg)](https://ko-fi.com/H2H7ALZTI)
